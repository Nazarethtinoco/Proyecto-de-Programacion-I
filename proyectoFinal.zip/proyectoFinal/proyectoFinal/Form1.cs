using Microsoft.VisualBasic.Logging;
using System.Runtime.InteropServices;

namespace proyectoFinal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(form1_load);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnMaximizar_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            BtnMaximizar.Visible = false;
            btnRestaurar.Visible = true;
        }


        private void btnRestaurar_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            btnRestaurar.Visible = false;
            BtnMaximizar.Visible = true;
        }

        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void form1_load(object sender, EventArgs e)
        {
            btnlog_Click(sender, e);
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int IParam);

        private void panelNavegacion_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            Submenuc.Visible = true;
        }

        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Submenuc.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Submenuc.Visible = false;
        }

        private void btnVendedor_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            MessageBox.Show("Como eres Vendedor, te pasaremos al INICIO DE SESION.", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Hide();

            LogIn login = new LogIn();
            login.FormClosed += (s, args) =>
            {
                this.Show();
            };
            login.ShowDialog();
        }
        

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void AbrirCatalogo(object Catalogo)
        {
            if (this.panelContenido.Controls.Count > 0)
                this.panelContenido.Controls.RemoveAt(0);
            Form fh = Catalogo as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.panelContenido.Controls.Add(fh);
            this.panelContenido.Tag = fh;
            fh.Show();

        }

        private void btnc_Click(object sender, EventArgs e)
        {
            AbrirCatalogo(new Catalogo());
        }

        private void btnlog_Click(object sender, EventArgs e)
        {
            AbrirCatalogo(new Bienvenida());
        }

    }
}
