﻿namespace proyectoFinal
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            textBox1 = new TextBox();
            panelNavegacion = new Panel();
            BtnMaximizar = new PictureBox();
            btnRestaurar = new PictureBox();
            btnMinimizar = new PictureBox();
            btnSalir = new PictureBox();
            panelMenu = new Panel();
            panel1 = new Panel();
            button5 = new Button();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            button3 = new Button();
            button4 = new Button();
            pictureBox7 = new PictureBox();
            btnV = new Button();
            pictureBox6 = new PictureBox();
            Submenuc = new Panel();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            button2 = new Button();
            btnc = new Button();
            btnCliente = new Button();
            btnlog = new PictureBox();
            panelContenido = new Panel();
            btnCatalogo = new Button();
            pictureBox2 = new PictureBox();
            btnFactura = new Button();
            pictureBox3 = new PictureBox();
            panelNavegacion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)BtnMaximizar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnRestaurar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnMinimizar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnSalir).BeginInit();
            panelMenu.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            Submenuc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnlog).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(0, 0);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(0, 23);
            textBox1.TabIndex = 0;
            // 
            // panelNavegacion
            // 
            panelNavegacion.BackColor = Color.FromArgb(192, 255, 255);
            panelNavegacion.Controls.Add(BtnMaximizar);
            panelNavegacion.Controls.Add(btnRestaurar);
            panelNavegacion.Controls.Add(btnMinimizar);
            panelNavegacion.Controls.Add(btnSalir);
            panelNavegacion.Dock = DockStyle.Top;
            panelNavegacion.Location = new Point(0, 0);
            panelNavegacion.Name = "panelNavegacion";
            panelNavegacion.Size = new Size(1300, 38);
            panelNavegacion.TabIndex = 1;
            panelNavegacion.MouseDown += panelNavegacion_MouseDown;
            // 
            // BtnMaximizar
            // 
            BtnMaximizar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            BtnMaximizar.Cursor = Cursors.Hand;
            BtnMaximizar.Image = (Image)resources.GetObject("BtnMaximizar.Image");
            BtnMaximizar.Location = new Point(1223, 7);
            BtnMaximizar.Name = "BtnMaximizar";
            BtnMaximizar.Size = new Size(25, 25);
            BtnMaximizar.SizeMode = PictureBoxSizeMode.Zoom;
            BtnMaximizar.TabIndex = 5;
            BtnMaximizar.TabStop = false;
            BtnMaximizar.Click += BtnMaximizar_Click_1;
            // 
            // btnRestaurar
            // 
            btnRestaurar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnRestaurar.Cursor = Cursors.Hand;
            btnRestaurar.Image = (Image)resources.GetObject("btnRestaurar.Image");
            btnRestaurar.Location = new Point(1223, 7);
            btnRestaurar.Name = "btnRestaurar";
            btnRestaurar.Size = new Size(25, 25);
            btnRestaurar.SizeMode = PictureBoxSizeMode.Zoom;
            btnRestaurar.TabIndex = 4;
            btnRestaurar.TabStop = false;
            btnRestaurar.Click += btnRestaurar_Click_1;
            // 
            // btnMinimizar
            // 
            btnMinimizar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMinimizar.Cursor = Cursors.Hand;
            btnMinimizar.Image = (Image)resources.GetObject("btnMinimizar.Image");
            btnMinimizar.Location = new Point(1182, 7);
            btnMinimizar.Name = "btnMinimizar";
            btnMinimizar.Size = new Size(25, 25);
            btnMinimizar.SizeMode = PictureBoxSizeMode.Zoom;
            btnMinimizar.TabIndex = 2;
            btnMinimizar.TabStop = false;
            btnMinimizar.Click += btnMinimizar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSalir.Cursor = Cursors.Hand;
            btnSalir.Image = (Image)resources.GetObject("btnSalir.Image");
            btnSalir.Location = new Point(1263, 7);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(25, 25);
            btnSalir.SizeMode = PictureBoxSizeMode.Zoom;
            btnSalir.TabIndex = 0;
            btnSalir.TabStop = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // panelMenu
            // 
            panelMenu.BackColor = Color.FromArgb(128, 255, 255);
            panelMenu.Controls.Add(panel1);
            panelMenu.Controls.Add(pictureBox7);
            panelMenu.Controls.Add(btnV);
            panelMenu.Controls.Add(pictureBox6);
            panelMenu.Controls.Add(Submenuc);
            panelMenu.Controls.Add(btnCliente);
            panelMenu.Controls.Add(btnlog);
            panelMenu.Dock = DockStyle.Left;
            panelMenu.Location = new Point(0, 38);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(200, 612);
            panelMenu.TabIndex = 2;
            panelMenu.Paint += panelMenu_Paint;
            // 
            // panel1
            // 
            panel1.Controls.Add(button5);
            panel1.Controls.Add(pictureBox8);
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button4);
            panel1.Location = new Point(37, 397);
            panel1.Name = "panel1";
            panel1.Size = new Size(163, 153);
            panel1.TabIndex = 16;
            panel1.Visible = false;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(128, 255, 255);
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            button5.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.Black;
            button5.Location = new Point(6, 102);
            button5.Name = "button5";
            button5.Size = new Size(144, 32);
            button5.TabIndex = 16;
            button5.Text = "Cliente Comp";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(10, 65);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(35, 19);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 15;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(11, 22);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(20, 20);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 14;
            pictureBox9.TabStop = false;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(128, 255, 255);
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            button3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.Black;
            button3.Location = new Point(6, 58);
            button3.Name = "button3";
            button3.Size = new Size(144, 32);
            button3.TabIndex = 13;
            button3.Text = "Ventas";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(128, 255, 255);
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            button4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.Black;
            button4.Location = new Point(6, 14);
            button4.Name = "button4";
            button4.Size = new Size(144, 32);
            button4.TabIndex = 12;
            button4.Text = "Inventario";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(21, 359);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(27, 32);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 18;
            pictureBox7.TabStop = false;
            // 
            // btnV
            // 
            btnV.BackColor = Color.FromArgb(128, 255, 255);
            btnV.FlatAppearance.BorderSize = 0;
            btnV.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            btnV.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnV.ForeColor = Color.Black;
            btnV.Location = new Point(12, 354);
            btnV.Name = "btnV";
            btnV.Size = new Size(167, 42);
            btnV.TabIndex = 17;
            btnV.Text = "Vendedor";
            btnV.UseVisualStyleBackColor = false;
            btnV.Click += btnVendedor_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(25, 190);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(27, 32);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 16;
            pictureBox6.TabStop = false;
            // 
            // Submenuc
            // 
            Submenuc.Controls.Add(pictureBox5);
            Submenuc.Controls.Add(pictureBox4);
            Submenuc.Controls.Add(button2);
            Submenuc.Controls.Add(btnc);
            Submenuc.Location = new Point(47, 226);
            Submenuc.Name = "Submenuc";
            Submenuc.Size = new Size(153, 100);
            Submenuc.TabIndex = 11;
            Submenuc.Visible = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(24, 62);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(20, 20);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 15;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(19, 20);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(20, 20);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 14;
            pictureBox4.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(128, 255, 255);
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            button2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Black;
            button2.Location = new Point(13, 57);
            button2.Name = "button2";
            button2.Size = new Size(134, 32);
            button2.TabIndex = 13;
            button2.Text = "Factura";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // btnc
            // 
            btnc.BackColor = Color.FromArgb(128, 255, 255);
            btnc.FlatAppearance.BorderSize = 0;
            btnc.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            btnc.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnc.ForeColor = Color.Black;
            btnc.Location = new Point(13, 14);
            btnc.Name = "btnc";
            btnc.Size = new Size(134, 32);
            btnc.TabIndex = 12;
            btnc.Text = "Catálogo";
            btnc.UseVisualStyleBackColor = false;
            btnc.Click += btnc_Click;
            // 
            // btnCliente
            // 
            btnCliente.BackColor = Color.FromArgb(128, 255, 255);
            btnCliente.FlatAppearance.BorderSize = 0;
            btnCliente.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            btnCliente.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCliente.ForeColor = Color.Black;
            btnCliente.Location = new Point(12, 185);
            btnCliente.Name = "btnCliente";
            btnCliente.Size = new Size(167, 42);
            btnCliente.TabIndex = 10;
            btnCliente.Text = "Cliente";
            btnCliente.UseVisualStyleBackColor = false;
            btnCliente.Click += btnCliente_Click;
            // 
            // btnlog
            // 
            btnlog.Image = (Image)resources.GetObject("btnlog.Image");
            btnlog.Location = new Point(0, 0);
            btnlog.Name = "btnlog";
            btnlog.Size = new Size(200, 170);
            btnlog.SizeMode = PictureBoxSizeMode.Zoom;
            btnlog.TabIndex = 6;
            btnlog.TabStop = false;
            btnlog.Click += btnlog_Click;
            // 
            // panelContenido
            // 
            panelContenido.BackColor = Color.White;
            panelContenido.Dock = DockStyle.Fill;
            panelContenido.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            panelContenido.Location = new Point(200, 38);
            panelContenido.Name = "panelContenido";
            panelContenido.Size = new Size(1100, 612);
            panelContenido.TabIndex = 0;
            // 
            // btnCatalogo
            // 
            btnCatalogo.BackColor = Color.FromArgb(128, 255, 255);
            btnCatalogo.FlatAppearance.BorderSize = 0;
            btnCatalogo.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            btnCatalogo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCatalogo.ForeColor = Color.Black;
            btnCatalogo.Location = new Point(14, 5);
            btnCatalogo.Name = "btnCatalogo";
            btnCatalogo.Size = new Size(134, 34);
            btnCatalogo.TabIndex = 8;
            btnCatalogo.Text = "Catálogo";
            btnCatalogo.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(21, 14);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(21, 18);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // btnFactura
            // 
            btnFactura.BackColor = Color.FromArgb(128, 255, 255);
            btnFactura.FlatAppearance.BorderSize = 0;
            btnFactura.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            btnFactura.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnFactura.ForeColor = Color.Black;
            btnFactura.Location = new Point(14, 45);
            btnFactura.Name = "btnFactura";
            btnFactura.Size = new Size(134, 34);
            btnFactura.TabIndex = 10;
            btnFactura.Text = "Factura";
            btnFactura.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(24, 51);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(22, 23);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1300, 650);
            Controls.Add(panelContenido);
            Controls.Add(panelMenu);
            Controls.Add(panelNavegacion);
            Controls.Add(textBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            panelNavegacion.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)BtnMaximizar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnRestaurar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnMinimizar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnSalir).EndInit();
            panelMenu.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            Submenuc.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnlog).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Panel panelNavegacion;
        private Panel panelMenu;
        private Button btnCliente;
        private Panel panelContenido;

        public Panel SubmenuC { get; private set; }

        private PictureBox btnSalir;
        private PictureBox btnMinimizar;
        private PictureBox btnRestaurar;
        private PictureBox BtnMaximizar;
        private PictureBox btnlog;
        private Button button3;
        private Panel panel1;
        private Button button2;
        private PictureBox pictureBox2;
        private Button btnFactura;
        private Button btnCatalogo;
        private PictureBox pictureBox3;
        private Panel Submenuc;
        private PictureBox pictureBox4;
        private Button btnc;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox7;
        private Button btnV;
        private Button button5;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private Button button4;
    }
}
